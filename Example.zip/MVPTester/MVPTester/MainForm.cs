﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace MVPTester
{
    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();
        }

        private void btnMVC_Click(object sender, EventArgs e)
        {
            MVCView _view = new MVCView();
            _view.Show();
        }

        private void btnMVP_Click(object sender, EventArgs e)
        {
  

            MVPView _view = new MVPView();
            _view.Show();
        }
    }
}
