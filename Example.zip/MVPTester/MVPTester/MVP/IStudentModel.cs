﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MVPTester
{
    interface IStudentModel
    {
        void Save(string username,string email );
        string Get(string username);
        bool ValidateEmail(string email);
        bool IsEntryExisting(string username);
       
        


    }
}
