﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace MVPTester
{

    public partial class MVPView : Form,IStudentView
    {
        Presenter _presenter;
        public MVPView()
        {
            InitializeComponent();

            _presenter = new Presenter(new Model(), this);
        }

        private void button1_Click(object sender, EventArgs e)
        
        {
          

            bool b = _presenter.IsEntryExisting(UserName);
            if (!b)
                _presenter.Save(UserName, Email);
                
            else
                MessageBox.Show("Entry already existing.");
        }


        public string UserName
        {
            get { return this.txtName.Text; }
            set { this.txtName.Text = value; }
        }

        public string Email
        {
            get { return this.txtEmail.Text; }
            set { this.txtEmail.Text = value; }
        }

    }
}
