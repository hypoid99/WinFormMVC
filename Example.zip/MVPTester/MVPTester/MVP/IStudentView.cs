﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MVPTester
{
    interface IStudentView
    {
        String UserName { get; set; }
        String Email { get; set; }

     
       


    }
}
