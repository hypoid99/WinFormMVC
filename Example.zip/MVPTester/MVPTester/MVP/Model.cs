﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MVPTester
{
    public class Model:IStudentModel
    {
        Dictionary<string,string> _repo = new Dictionary<string,string>();

        public void Save(string username,string email)
        {
            
            _repo.Add(username, email);
        }

        public string Get(string username)
        {
            try
            {
                return _repo[username];
            }
            catch (Exception ex)
            {
                return String.Empty;
            }
        }

        public bool ValidateEmail(string email)
        {
            return true;
        }

        public bool IsEntryExisting(string username)
        {
            return (Get(username) != String.Empty);
        }



    }
}
