﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MVPTester
{
    interface ICommands
    {
         void Execute();
         Model CurrentModel { get; set; }
    }


    public class SaveCommand : ICommands
    {
        string _username = "";
        string _email = "";
        //Model _model;
        public Model CurrentModel { get; set; }
        //public Model CurrentModel
        //{
        //    get
        //    {
        //        return _model;
        //    }

        //    set
        //    {
        //        _model = value;
        //    }
        //}
      

        public SaveCommand(string username, string email)
        {
            _username = username;
            _email = email;
        }

        public void Execute()
        {

            CurrentModel.Save(_username,_email);
        }

    }




    class Presenter
    {
        IStudentModel _model;
        IStudentView _view;

        public Presenter(IStudentModel model, IStudentView view)
        {
            _model = model;
            _view = view;
           
        }
        public void Save(string username, string email)
        {
            
            _model.Save(username, email);
        }

        public void Execute(ICommands command)
        {
            command.CurrentModel = (Model)_model;
            command.Execute();
        }

        public bool IsEntryExisting(string username)
        {
            return _model.IsEntryExisting(username);
        
        }
    }
}
