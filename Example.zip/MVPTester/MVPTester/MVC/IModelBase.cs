﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ComponentModel;

namespace MVPTester
{
    public abstract class ModelBase
    {
        public abstract void Save(string username, string email);
        public abstract string Get(string username);
        public abstract bool ValidateEmail(string email);
        public abstract bool IsEntryExisting(string username);
       
        public event EventHandler ModelChanged;

        protected void Fire_ModelChanged(object sender, EventArgs e)
        {

            ModelChanged(sender, e);
        }

        
    }
}
