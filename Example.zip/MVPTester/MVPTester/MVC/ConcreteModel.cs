﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MVPTester
{
    class ConcreteModel:ModelBase
    {
        Dictionary<string, string> _repo = new Dictionary<string, string>();

        override public void Save(string username, string email)
        {

            _repo.Add(username, email);

            Fire_ModelChanged(this, null);
        }

        public int GetTotalRecords()
        {
            return _repo.Count;

        }

        override public string Get(string username)
        {
            try
            {
                return _repo[username];
            }
            catch (Exception ex)
            {
                return String.Empty;
            }
        }

        override public bool ValidateEmail(string email)
        {
            return true;
        }

        override public bool IsEntryExisting(string username)
        {
            return (Get(username) != String.Empty);
        }
    }
}
