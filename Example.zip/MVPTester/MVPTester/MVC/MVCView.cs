﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace MVPTester
{
    public partial class MVCView : Form, IViewBase
    {
        public MVCView()
        {
            InitializeComponent();

            
        }



         public string UserName
        {
            get
            {
                return txtUsername.Text;
            }
            set
            {
                txtUsername.Text = value;
            }

        }

         public string Email
        {
            get
            {
                return txtEmail.Text;
            }

            set
            {
                txtEmail.Text = value;

            }

        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            new Controller(this).Save();
        }

        public void ChangedState(object sender, EventArgs e)
        {
            ConcreteModel concModel = (ConcreteModel)sender;

            int total  = concModel.GetTotalRecords();
            MessageBox.Show("The total count in the database is: " + total.ToString());

        }


    

    }
}
