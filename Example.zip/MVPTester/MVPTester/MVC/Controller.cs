﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MVPTester
{
    class Controller
    {

        IViewBase _view = null;
        ConcreteModel _model = new ConcreteModel();
        public Controller(IViewBase view)
        {

            _view = view;
            _model.ModelChanged += new EventHandler(_model_ModelChanged);
            

        }

        void _model_ModelChanged(object sender, EventArgs e)
        {
            if (_view == null)
                return;

          
                _view.ChangedState(sender, e);
           
        }

        public void Save()
        {
           
            if (!_model.IsEntryExisting(_view.UserName))
            {
                _model.Save(_view.UserName, _view.Email);

            }
        }


    }
}
